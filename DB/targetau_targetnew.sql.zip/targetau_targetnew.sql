-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Mar 31, 2016 at 06:54 AM
-- Server version: 5.5.32-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `targetau_targetnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `suplier`
--

CREATE TABLE IF NOT EXISTS `suplier` (
  `suplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `serial` varchar(255) NOT NULL,
  `sending_date` varchar(255) NOT NULL,
  `vendor` int(11) NOT NULL,
  `style` varchar(255) NOT NULL,
  `pack_no` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `submitfor_approval` varchar(255) NOT NULL,
  `submition_no` varchar(255) NOT NULL,
  `tgt_note` text NOT NULL,
  `buyer_comments` text NOT NULL,
  `approve` int(11) NOT NULL,
  `submit_date` date NOT NULL,
  `approve_date` date NOT NULL,
  `create_to` int(11) NOT NULL,
  `receive_to` int(11) NOT NULL,
  `buyerteam` int(11) NOT NULL,
  PRIMARY KEY (`suplier_id`),
  UNIQUE KEY `serial` (`serial`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=87 ;

--
-- Dumping data for table `suplier`
--

INSERT INTO `suplier` (`suplier_id`, `serial`, `sending_date`, `vendor`, `style`, `pack_no`, `color`, `item_desc`, `submitfor_approval`, `submition_no`, `tgt_note`, `buyer_comments`, `approve`, `submit_date`, `approve_date`, `create_to`, `receive_to`, `buyerteam`) VALUES
(1, '0001', '23-Mar-2016', 8, '3200097105', 'B', 'Target WHITE', 'Strike off', 'Design, size, color ', '1st ', '', '', 0, '2016-03-22', '0000-00-00', 29, 11, 19),
(2, '0002', '23-Mar-2016', 8, '3200092860', 'C', 'Target White', 'Strike off', 'Design, size, color ', '1st', '', '', 0, '2016-03-22', '0000-00-00', 29, 11, 19),
(3, '0003', '23-Mar-2016', 8, '3200092860', 'D', 'Target WHITE', 'Strike off', 'Design, size, color ', '1st ', '', '', 0, '2016-03-22', '0000-00-00', 29, 11, 19),
(4, '0004', '23-Mar-2016', 8, '3200092861', 'C', 'Target White / Target Black', 'Strike off', 'Design, size, color ', '1st ', '', '', 0, '2016-03-22', '0000-00-00', 29, 11, 19),
(5, '0005', '23-Mar-2016', 8, '3200101418', 'N/A', 'Target WHITE', 'Strike off', 'Design, size, color ', '1st ', '', '', 0, '2016-03-22', '0000-00-00', 29, 11, 19),
(6, '0006', '23-Mar-2016', 8, '3200092106', 'O', 'Grey Marle', 'Strike off', 'Design, size, color ', '2nd ', '', '', 0, '2016-03-22', '0000-00-00', 29, 11, 19),
(7, '0007', '23-Mar-2016', 8, '3200092106', 'V', 'Eclipse', 'Strike off', 'size ', '2nd ', '', '', 0, '2016-03-22', '0000-00-00', 29, 11, 19),
(8, '0008', '', 8, '3200092870', 'A', 'VMGR116 ', 'Strike off', 'Design, size, color ', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 0),
(9, '0009', '', 8, '3200092870', 'B', 'VMRD21', 'Strike off', 'Design, size, color ', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 0),
(10, '0010', '23-Mar-2016', 8, '3200092106', 'Q', 'Transparent Yellow', 'Lab Dip', 'For color', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(11, '0011', '23-Mar-2016', 8, '3200092106', 'U', 'Azalea Pink', 'Lab Dip', 'For color', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(12, '0012', '23-Mar-2016', 8, '3200092106', 'S', 'Mermaid', 'Lab Dip', 'For color', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(13, '0013', '23-Mar-2016', 8, '3200092106', 'M', 'Hot coral', 'Lab Dip', 'For color ', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(14, '0014', '23-Mar-2016', 8, '3200092106', 'M', 'Hot coral ', 'Strike off', 'Design, size, color ', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(15, '0015', '23-Mar-2016', 8, '3200092106', 'P', 'Impatiens pink', 'Strike off', 'Design, size, color ', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(16, '0016', '23-Mar-2016', 8, '3200092106', 'W', 'Teaberry', 'Strike off', 'Design, size, color ', '2nd ', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(17, '0017', '23-Mar-2016', 9, '3200092850', 'C', 'Persian Jewel ', 'Twill Tape', 'Color,quality,Design', '1st', 'n/a', '', 0, '2016-03-23', '0000-00-00', 30, 11, 19),
(18, '0018', '25-Mar-2016', 8, '3200092106', 'R', 'Blue Light', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(19, '0019', '25-Mar-2016', 8, '3200092106', 'N', 'Target White', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-23', '0000-00-00', 29, 11, 19),
(20, '0020', '', 15, '3550096752', 'N/A', 'hot pink', 'lab-dips', 'color approval', '1st', 'n/a', '', 0, '2016-03-24', '0000-00-00', 46, 12, 0),
(21, '0021', '25-Mar-2016', 8, '3700089917', 'D', 'Base-Target White', 'AOP Strike off', 'Color, Design and Quality.', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(22, '0022', '25-Mar-2016', 8, '3700089924', 'E', 'Base-Target White', 'AOP Strike Off', 'Color, Design,Quality.', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(23, '0023', '25-Mar-2016', 8, '3700089924', 'H', 'Base-Target White', 'Aop Strike Off', 'Color, Design, Quality', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(24, '0024', '25-Mar-2016', 8, '3700089948', 'B', 'Base- Target White', 'Aop strike off', 'Color, Design, Quality.', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(25, '0025', '25-Mar-2016', 8, '3700089956', 'A', 'Base- Target White', 'AOP strike off', 'Color, Design, Quality.', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(26, '0026', '25-Mar-2016', 8, '3700089917 ', 'D', 'Medieval Blue', 'Print Strike Off', 'Coor, Quality, Design.', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(27, '0027', '25-Mar-2016', 8, '3700089924 ', 'F', 'Crystal Blue', 'Print Strike Off.', 'Color, Quality, Design', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(28, '0028', '25-Mar-2016', 8, '3700089924 ', 'G', 'Y/D(White/Black)', 'Print Strike Off', 'Color, Quality, Design', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(29, '0029', '25-Mar-2016', 8, '3700089924 ', 'H', 'Target White', 'Print Strike Off', 'Color, Quality, Design.', '1st', '', '', 0, '2016-03-24', '0000-00-00', 28, 5, 14),
(30, '0030', '', 8, '3200100648', 'N/A', 'Target White (AOP)', 'Strike off', 'Design, size, color ', '1st ', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 0),
(31, '0031', '', 8, '3200092861', 'C', 'Target White', 'Yarn Dip', 'Color approval', '1st ', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 0),
(32, '0032', '', 8, '3200092861', 'C', 'Target Black', 'Yarn Dip', 'Color approval', '1st ', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 0),
(33, '0033', '', 8, '3550093389', 'C', 'Grey Marle', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-24', '0000-00-00', 29, 12, 0),
(34, '0034', '25-Mar-2016', 8, '3200092861', 'C', 'Target Black', 'Yarn Dip', 'Color approval', '1st ', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 19),
(35, '0035', '25-Mar-2016', 8, '3200100871', 'A', 'Lime Light', 'Lab Dip', 'For color approval', '1st ', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 19),
(36, '0036', '25-Mar-2016', 8, '3200100871', 'B', 'Fuchsia Purple', 'Lab Dip', 'For color approval', '1st ', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 19),
(37, '0037', '', 8, '3550093389', 'D', 'Grey Marle', 'Strike off', 'Design, size, color ', '1st ', '', '', 0, '2016-03-24', '0000-00-00', 29, 12, 0),
(38, '0038', '25-Mar-2016', 8, '3200092106', 'Q', 'Transparent Yellow', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 19),
(39, '0039', '25-Mar-2016', 8, '3200092106', 'U', 'Azalea Pink', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-24', '0000-00-00', 29, 11, 19),
(40, '0040', '29-Mar-2016', 8, '3550096753', 'A', 'Fluro Pink', 'Gros Grain Ribbon', 'Design, size, color ', '1st ', '', '', 0, '2016-03-28', '0000-00-00', 29, 12, 17),
(41, '0041', '29-Mar-2016', 8, '3550096750', 'B', 'Fuchsia Purple', 'Lurex Elastic', 'Design, size, color ', '1st ', '', '', 0, '2016-03-28', '0000-00-00', 29, 12, 17),
(42, '0042', '29-Mar-2016', 8, '3700089917', 'E', 'Base-Target White', 'AOP Strike Off', 'Colour,Quality,Design. ', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 14),
(43, '0043', '29-Mar-2016', 8, '3700089924', 'F', 'Base-Target White', 'AOP Strike Off', 'Colour, Quality, Design', '1st', 'we will improve Hand feel in machine sample.pls advise .', '', 0, '2016-03-29', '0000-00-00', 28, 5, 14),
(44, '0044', '29-Mar-2016', 1, '3550097861/97862', 'A', 'Omphalodes with multi-colour', 'AOP strike off', 'color ,quality ', '1st ', '', '', 0, '2016-03-29', '0000-00-00', 21, 12, 16),
(45, '0045', '29-Mar-2016', 8, '3700089944', 'A', 'Base-Target White', 'AOP Strike Off', 'Colour,Quality,Design.', '1st', 'In bulk production print shade will be variation.pls advise.', '', 0, '2016-03-29', '0000-00-00', 28, 5, 14),
(46, '0046', '29-Mar-2016', 8, '3700089948', 'A', 'Base-Target white', 'AOP Strike Off', 'Colour,Quality,Design.', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 14),
(47, '0047', '29-Mar-2016', 8, '3700089956', 'B', 'Base-Target White', 'AOP Strike Off', 'Colour,Quality,Design.', '1st', 'we will Improve hand feel in machine sample.pls advise.', '', 0, '2016-03-29', '0000-00-00', 28, 5, 14),
(48, '0048', '29-Mar-2016', 8, '3700089948', 'B', 'Target White', 'Print Strike Off.', 'Colour,Quality,Design', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 14),
(49, '0049', '29-Mar-2016', 9, '3550093402', 'B', 'pink leamonad', 'gross grain Tape (option: A and B)', 'submited only for colour approval (quality already approved)', '2nd', 'please consider as a best submission for this trims.', '', 0, '2016-03-29', '0000-00-00', 30, 12, 17),
(50, '0050', '29-Mar-2016', 9, '3550093399', 'A', 'dark wash', 'wshiker option: A (shade 1/2/3) whshiker option: B (shade onlt 1)', 'submited for shade and wshiker approval', '1st', 'please consider as a best submission for this trims.', '', 0, '2016-03-29', '0000-00-00', 30, 12, 16),
(51, '0051', '', 4, '3550097867', 'A', 'INSIGNIA-18-4028 TCX', 'LAB-DIB', 'Color', '3rd', 'N/A', '', 0, '2016-03-29', '0000-00-00', 47, 12, 0),
(52, '0052', '', 14, '3550093395', 'A', 'Dazzling Blue', 'Plastic button ', 'For color and quality approval', '1', '', '', 0, '2016-03-29', '0000-00-00', 45, 12, 0),
(53, '0053', '', 14, '3550093395', 'B', 'White', 'Plastic Button', 'For color and quality approval', '1', '', '', 0, '2016-03-29', '0000-00-00', 45, 12, 0),
(54, '0054', '', 14, '3550092638', 'A', 'White', 'Ring press button', 'For color and quality approval', '1', '', '', 0, '2016-03-29', '0000-00-00', 45, 12, 0),
(55, '0055', '', 14, '3550092638', 'B', 'Grey (H101 CY)', 'Ring press button', 'For color and quality approval', '1', '', '', 0, '2016-03-29', '0000-00-00', 45, 12, 0),
(56, '0056', '', 14, '3550093394', 'E', 'Beach Glass', 'Plastic Button', 'For color and quality approval', '1', '', '', 0, '2016-03-29', '0000-00-00', 45, 12, 0),
(57, '0057', '', 8, '3550093406', 'D', 'Target White (AOP)', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-29', '0000-00-00', 29, 12, 0),
(58, '0058', '', 8, '3700089917 ', 'D', 'Hot Coral', 'Lab Dip(For Neck Tape)', 'Swatch Color', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 0),
(59, '0059', '', 8, '3700089944', 'B', 'Aspen Gold', 'Lab Dip(For Neck Tape)', 'Swatch Color', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 0),
(60, '0060', '', 8, '3700089948', 'A', 'Hot Coral and Target Black', 'Yarn Dip', 'Yarn Colour', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 0),
(61, '0061', '', 8, '3700089954', 'A', 'Asphalt', 'Lab Dip', 'Swatch Colour', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 0),
(62, '0062', '', 8, '3700089954', 'A', 'Pool Green', 'Lab Dip(For Neck Tape)', 'Swatch Colour', '1st', '', '', 0, '2016-03-29', '0000-00-00', 28, 5, 0),
(63, '0063', '', 8, '3700089917 ', 'E', 'Ice Grey Marle', 'Print Strike Off', 'Colour,Quality,Design.', '1st', '', '', 0, '2016-03-30', '0000-00-00', 28, 5, 0),
(64, '0064', '', 8, '3700089944', 'B', 'Base-Target White', 'Aop Strike Off', 'Colour,Quality, Design.', '1st(Option-A)', '', '', 0, '2016-03-30', '0000-00-00', 28, 5, 0),
(65, '0065', '', 8, '3700089944', 'B', 'Base-Grey Marle', 'Aop Strike Off', 'Color,Quality,Design', '1st(Option-B)', '', '', 0, '2016-03-30', '0000-00-00', 28, 5, 0),
(66, '0066', '', 8, '3400101630', 'CW1', 'Poppy Red', 'Lab Dip', 'For color approval', '3rd', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(67, '0067', '', 8, '3400093053', 'CW18', 'Barly Pink', 'Lab Dip', 'For color approval', '3rd', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(68, '0068', '', 8, '3400099503 ', 'CW2', 'Liight neon Peach', 'Lab Dip', 'For color approval', '3rd', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(69, '0069', '', 8, '3400093053', 'CW24', 'Desert Flower', 'Lab Dip', 'For color approval', '3rd', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(70, '0070', '', 8, '3400093053', 'CW26', 'Sunny Lime', 'Lab Dip', 'For color approval', '3rd', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(71, '0071', '', 8, '3400095511', 'CW1', 'Sunny Lime ( 100% viscose)', 'Lab Dip', 'For color approval', '4th', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(72, '0072', '', 8, '3400093061 ', 'CW4', 'Orchid', 'Lab Dip', 'For color approval', '3rd', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(73, '0073', '', 8, '3400095511', 'CW2', 'Orchid', 'Lab Dip ( 100% viscose)', 'For color approval', '3rd', '', '', 0, '2016-03-30', '0000-00-00', 28, 3, 0),
(74, '0074', '', 8, '3550093391', 'G', 'Beach Glass', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-30', '0000-00-00', 29, 12, 0),
(75, '0075', '', 8, '3550093391', 'J', 'Fuchsia Purple', 'Strike off', 'Design, size, color ', '2nd', '', '', 0, '2016-03-30', '0000-00-00', 29, 12, 0),
(76, '0076', '', 8, '3550093390', 'N', 'Emerald', 'Strike off', 'color ', '2nd', '', '', 0, '2016-03-30', '0000-00-00', 29, 12, 0),
(77, '0077', '', 8, '3550093390', 'I', 'Parakeet', 'Strike off', 'color only', '2nd', '', '', 0, '2016-03-30', '0000-00-00', 29, 12, 0),
(78, '0078', '', 8, '3550093390', 'G', 'Grey Marle', 'Strike off', 'Color approval', '2nd', '', '', 0, '2016-03-30', '0000-00-00', 29, 11, 0),
(79, '0079', '', 8, '3550097866', 'A', 'Grey Marle (AOP)', 'Strike off', 'Color approval of Gradient print', '2nd', '', '', 0, '2016-03-30', '0000-00-00', 29, 12, 0),
(80, '0080', '', 13, '3700089950', 'A', 'BUGS', 'WOVEN WRAP BADGE LABEL', 'COLOR,QUALITY,DESIGN', '1ST (IN 3 OPTIONS),REMARKS-WE HAVE ALSO SUBMITTED ANOTHER OPTION IN PP SAMPLE.', '', '', 0, '2016-03-31', '0000-00-00', 44, 5, 0),
(81, '0081', '', 8, '3400093053', 'CW18', 'Barly Pink', 'Print strike off', 'For color approval', '3rd', '', '', 0, '2016-03-31', '0000-00-00', 28, 3, 0),
(82, '0082', '', 8, '3400093053', 'CW24', 'Desert flower', 'Print striek off', 'For color approval', '3rd', '', '', 0, '2016-03-31', '0000-00-00', 28, 3, 0),
(83, '0083', '', 8, '3400093053 ', 'CW15', 'White', 'Print strike off', 'For color approval', '3rd', '', '', 0, '2016-03-31', '0000-00-00', 28, 3, 0),
(84, '0084', '', 8, '3400093053', 'CW17', 'Peacoat', 'Print strike off', 'For color approval', '3rd', '', '', 0, '2016-03-31', '0000-00-00', 28, 3, 0),
(85, '0085', '', 8, '3400093053', 'CW16', 'White', 'Print strike off', 'for color approval', '3rd', '', '', 0, '2016-03-31', '0000-00-00', 28, 3, 0),
(86, '0086', '', 8, '3700089952', 'A', 'Base- Target White', 'Aop Strike Off', 'Color, Quality,Design.', '1st', '', '', 0, '2016-03-31', '0000-00-00', 28, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tr_company`
--

CREATE TABLE IF NOT EXISTS `tr_company` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` text NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tr_company`
--

INSERT INTO `tr_company` (`vendor_id`, `vendor_name`) VALUES
(1, 'DIVINE'),
(2, 'Aman Graphics'),
(3, 'Civic'),
(4, 'INTRAMEX'),
(5, 'Aman Knitting'),
(6, 'Fashion Forum'),
(7, 'KDS'),
(8, 'SHANTA'),
(9, 'NORP'),
(10, 'NEWAGE'),
(11, 'Tamishna'),
(12, 'Roverco'),
(13, 'Renaissance'),
(14, 'IRIS'),
(15, 'Impress-Newtex'),
(16, 'PANORAMA');

-- --------------------------------------------------------

--
-- Table structure for table `tr_item_ifno`
--

CREATE TABLE IF NOT EXISTS `tr_item_ifno` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `serialno` varchar(255) NOT NULL,
  `sending_date` varchar(255) NOT NULL,
  `vendor` varchar(255) NOT NULL,
  `style_no` varchar(255) NOT NULL,
  `pkno` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `item_size` varchar(255) NOT NULL,
  `fabirc` varchar(255) NOT NULL,
  `care_label` varchar(255) NOT NULL,
  `hanger` varchar(255) NOT NULL,
  `price_tag` varchar(255) NOT NULL,
  `sewing_tag` varchar(255) NOT NULL,
  `sample_qtn` varchar(255) NOT NULL,
  `approve_status` int(11) NOT NULL,
  `tgt_comment` text NOT NULL,
  `tssq_comment` text NOT NULL,
  `entry_date` date NOT NULL,
  `approve_date` date NOT NULL,
  `create_to` int(11) NOT NULL,
  `receive_to` int(11) NOT NULL,
  `buyerteam` int(11) NOT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `serialno` (`serialno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `tr_item_ifno`
--

INSERT INTO `tr_item_ifno` (`item_id`, `serialno`, `sending_date`, `vendor`, `style_no`, `pkno`, `color`, `method`, `item_size`, `fabirc`, `care_label`, `hanger`, `price_tag`, `sewing_tag`, `sample_qtn`, `approve_status`, `tgt_comment`, `tssq_comment`, `entry_date`, `approve_date`, `create_to`, `receive_to`, `buyerteam`) VALUES
(1, '0001', '21-Mar-2016', '1', '3500079798', 'A', 'black', 'PP Sample', '4', 'actual', 'actual', 'actual', 'actual', 'actual', 'actual', 0, 'n/a', '', '2016-03-21', '0000-00-00', 21, 3, 13),
(2, '0002', '', '1', '375009896', 'B', 'white', 'PP Sample', '10', 'actual', 'actual', 'actual', 'actual', 'actual', 'actual', 0, 'n/a', '', '2016-03-21', '0000-00-00', 21, 5, 0),
(3, '0003', '23-Mar-2016', '8', '3200092860', 'A', 'Tropical peach', 'PP Sample', '10', 'Actual', 'Available', 'Available', 'Missing', 'Actual', '4', 0, '', '', '2016-03-22', '0000-00-00', 29, 11, 19),
(4, '0004', '25-Mar-2016', '8', '3200092860', 'B', 'Target White', 'PP Sample', '10', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '4', 0, '', '', '2016-03-23', '0000-00-00', 29, 11, 19),
(5, '0005', '25-Mar-2016', '8', '3200097105', 'A', 'Target White', 'PP Sample', '10', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '4', 0, '', '', '2016-03-23', '0000-00-00', 29, 11, 19),
(6, '0006', '', '8', '3550093391', 'E', 'Pink Lemonade', 'PP Sample', '000 ', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '8', 0, '', '', '2016-03-24', '0000-00-00', 29, 12, 0),
(7, '0007', '25-Mar-2016', '8', '3200092855', 'A', 'Tropical peach', 'PP Sample', '10', 'Actual', 'Available', 'Available', 'Missing', 'Actual', '4', 0, '', '', '2016-03-24', '0000-00-00', 29, 11, 19),
(8, '0008', '', '8', '3550093391', 'D', 'Orchid Pink', 'PP Sample', '000 ', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '8', 0, '', '', '2016-03-24', '0000-00-00', 29, 12, 0),
(9, '0009', '25-Mar-2016', '8', '3200092855', 'B', 'Blue Light', 'PP Sample', '10', 'Actual', 'Available', 'Available', 'Missing', 'Actual', '4', 0, '', '', '2016-03-24', '0000-00-00', 29, 11, 19),
(10, '0010', '25-Mar-2016', '8', '3200101418', 'n/a', 'Grey marle', 'Range review', '10', 'Actual', 'Available', 'Available', 'Available', 'Available', '2', 0, 'n/a', '', '2016-03-25', '0000-00-00', 27, 11, 19),
(11, '0011', '25-Mar-2016', '8', '34000101861', 'CW1', 'Neon Orange', 'Range review', '4', 'actual', 'actual', 'actual', 'Available', 'Available', '1', 0, 'N/A', '', '2016-03-25', '0000-00-00', 28, 3, 15),
(12, '0012', '25-Mar-2016', '13', '3700089718', 'B', 'AOP', 'PP Sample', '2-7', 'ACTUAL', 'AVAILABLE', 'AVAILABLE', 'ACTUAL', 'ACTUAL', '3', 0, '', '', '2016-03-25', '0000-00-00', 43, 5, 14),
(13, '0013', '25-Mar-2016', '13', '3700089929 ', 'A', 'MONSTER SPACE', 'PP Sample', '4', 'ACTUAL', 'AVAILABLE', 'ACTUAL', 'MISSING', 'ACTUAL', '05', 0, '', '', '2016-03-25', '0000-00-00', 44, 5, 14),
(14, '0014', '25-Mar-2016', '13', '3700089927', 'A', 'MONSTER SPACE', 'PP Sample', '4', 'ACTUAL', 'AVAILABLE', 'ACTUAL', 'MISSING', 'ACTUAL', '05', 0, 'n/a', '', '2016-03-25', '0000-00-00', 44, 5, 14),
(15, '0015', '25-Mar-2016', '13', '3700089736', 'A', 'Dazzling blue', 'PP Sample', '8-16', 'actual', 'actual', 'available', 'actual', 'actual', '3', 0, '', '', '2016-03-25', '0000-00-00', 43, 5, 14),
(16, '0016', '25-Mar-2016', '13', '3700089737', 'A', 'dazzling blue', 'PP Sample', '8-16', 'actual', 'actual', 'available', 'actual', 'actual', '03', 0, '', '', '2016-03-25', '0000-00-00', 43, 5, 14),
(17, '0017', '29-Mar-2016', '8', '3700089924 ', 'A', 'Top-Ice Grey Marle, Bottom-Base-White(Aop)', 'PP Sample', '4', 'Actual', 'Available', 'Actual', 'Missing', 'Missing', '5 Set(10 Pcs)', 0, '', '', '2016-03-28', '0000-00-00', 28, 5, 14),
(18, '0018', '29-Mar-2016', '8', '3700089917 ', 'B', 'Top-Ice Grey Marle, Bottom-Base-White(Aop)', 'PP Sample', '10', 'Actual', 'Available', 'Available', 'Missing', 'Missing', '5 Set(10-Pcs)', 0, '', '', '2016-03-28', '0000-00-00', 28, 5, 14),
(19, '0019', '29-Mar-2016', '8', '3550093390', 'D', 'Grey Marle', 'PP Sample', '000 ', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '8', 0, '', '', '2016-03-28', '0000-00-00', 29, 12, 16),
(20, '0020', '29-Mar-2016', '8', '3550093390', 'F', 'Aspen Gold', 'PP Sample', '000 ', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '8', 0, '', '', '2016-03-28', '0000-00-00', 29, 12, 16),
(21, '0021', '29-Mar-2016', '3', '3200092815', 'N/A', 'Black wash', 'PP Sample', '10', '73% Cotton 25% Polyester 2% Spandex ', 'Actual', 'avalable ', 'missing', 'actual', '4 pcs', 0, '', '', '2016-03-29', '0000-00-00', 48, 11, 19),
(22, '0022', '29-Mar-2016', '8', '3700089731 ', 'A', 'Top Front-White,Top Back-Grey Marle,Bottom-Base-white.', 'PP Sample', '10', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '5set(10 Pcs)', 0, '', '', '2016-03-29', '0000-00-00', 28, 5, 14),
(23, '0023', '', '14', '3700089938', '-', 'Grey/Navy', 'PP Sample', '10', 'Actual', 'Available', 'Actual', 'N/A', 'N/A', '04 pcs', 0, '', '', '2016-03-29', '0000-00-00', 45, 5, 0),
(24, '0024', '', '13', '3700089950', 'A', 'BUGS', 'PP Sample', '0', 'ACTUAL', 'AVAILABLE', 'ACTUAL', 'MISSING', 'ACTUAL', '05', 0, '', '', '2016-03-30', '0000-00-00', 44, 5, 0),
(25, '0025', '', '15', '3550093757', 'A', 'ICE GREY MARLE', 'PP Sample', '000/0', 'YES', 'Available', 'Available', 'NO', 'NO', '6', 0, '', '', '2016-03-30', '0000-00-00', 46, 12, 0),
(26, '0026', '', '15', '3550097864', 'A', 'Avalable', 'Red Tag', '000/0', 'Available', 'Available', 'NO', 'NO', 'NO', '6', 0, '', '', '2016-03-30', '0000-00-00', 46, 12, 0),
(27, '0027', '', '15', '3550097876', 'A', 'Available', 'Red Tag', '000/0', 'Available', 'Available', 'NO', 'NO', 'NO', '6', 0, '', '', '2016-03-30', '0000-00-00', 46, 12, 0),
(28, '0028', '', '15', '3550082215', 'A', 'Grey Marle', 'Red Tag', '000/0', 'Grey Marle', 'Available', 'NO', 'NO', 'NO', '6', 0, '', '', '2016-03-30', '0000-00-00', 46, 12, 0),
(29, '0029', '', '15', '3550088129', 'A', 'Grey Marle', 'Red Tag', '000/0', 'Grey Marle', 'Available', 'NO', 'NO', 'NO', '6', 0, '', '', '2016-03-30', '0000-00-00', 46, 12, 0),
(30, '0030', '', '8', '3400093058 ', 'CW1', 'Pool Green', 'PP Sample', '2 ', 'Actual', 'Available', 'Actual', 'Available', 'Actual', '8 pcs', 0, '', '', '2016-03-30', '0000-00-00', 28, 3, 0),
(31, '0031', '', '8', '3400093063', 'CW3', 'Yellow cream', 'PP Sample', '2 ', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '8 pcs', 0, '', '', '2016-03-30', '0000-00-00', 28, 3, 0),
(32, '0032', '', '8', '3400097222', 'CW1', 'Available', 'Red Tag', '2 ', 'Fabrication: actual, Color: Available', 'Available', 'missing', 'missing', 'missing', '11 pcs ( 2 option)', 0, '', '', '2016-03-31', '0000-00-00', 28, 3, 0),
(33, '0033', '', '8', '3550093405', 'C', 'Strong Blue / Azure Blue', 'PP Sample', '000 ', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '8', 0, '', '', '2016-03-31', '0000-00-00', 29, 12, 0),
(34, '0034', '', '8', '3550093406', 'A', 'Target White (AOP)', 'PP Sample', '000 ', 'Actual', 'Available', 'Actual', 'Missing', 'Actual', '8', 0, '', '', '2016-03-31', '0000-00-00', 29, 12, 0),
(35, '0035', '', '8', '3700089948', 'A', 'Top-Base-White,Bottom-Y/D Stripe(T.Black Hot Coral)', 'Range review', '10', 'Actual', 'Available', 'Available', 'Missing', 'Missing', '02 Set(04 Pcs)', 0, '', '', '2016-03-31', '0000-00-00', 28, 5, 0),
(36, '0036', '', '8', '3700089948', 'B', 'Top--T. White, Bottom-Base-T. White', 'Range review', '10', 'Actual', 'Available', 'Available', 'Missing', 'Missing', '02 Set(04 Pcs)', 0, '', '', '2016-03-31', '0000-00-00', 28, 5, 0),
(37, '0037', '', '8', '3700089944', 'B', 'Top Bottom-Base-T. White', 'Range review', '4', 'Actual', 'Available', 'Available', 'Missing', 'Missing', '02 Set(04 Pcs)', 0, 'We have use neck tape closer color.pls consider. ', '', '2016-03-31', '0000-00-00', 28, 5, 0),
(38, '0038', '', '8', '3700089924 ', 'H', 'Top-T. White, Bottom-Base-T. White.', 'Range review', '4', 'Actual', 'available', 'available', 'Missing', 'Missing', '02 Set(04 Pcs)', 0, '', '', '2016-03-31', '0000-00-00', 28, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tr_user`
--

CREATE TABLE IF NOT EXISTS `tr_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `vendorid` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tr_user`
--

INSERT INTO `tr_user` (`user_id`, `username`, `password`, `email`, `status`, `vendorid`) VALUES
(1, 'admin', '356282e2d4590c4ba6543df3b9cba9f9', 'admin@gmail.com', 999, '0'),
(3, 'TAS01', '81dc9bdb52d04dc20036dbd8313ed055', 'Aklima.Haque@tgasourcing.com', 1, '0'),
(5, 'TAS02', '65d2ea03425887a717c435081cfc5dbb', 'Rezona.Akter@tgasourcing.com', 1, '0'),
(11, 'TAS03', '81dc9bdb52d04dc20036dbd8313ed055', 'Hasnat.Abul@tgasourcing.com', 1, '0'),
(12, 'TAS04', '81dc9bdb52d04dc20036dbd8313ed055', 'Shoma.Begum@tgasourcing.com', 1, '0'),
(13, 'TSSO03', '81dc9bdb52d04dc20036dbd8313ed055', 'Eva.Collado@target.com.au', 6, 'byer'),
(14, 'TSSO04', '81dc9bdb52d04dc20036dbd8313ed055', 'Joanne.Rolski@target.com.au', 6, 'byer'),
(15, 'TSSO05', '81dc9bdb52d04dc20036dbd8313ed055', 'Debbie.Apponyi@target.com.au', 6, 'byer'),
(16, 'TSSO06', '21232f297a57a5a743894a0e4a801fc3', 'Bryce.Cresswell@target.com.au', 6, 'byer'),
(17, 'TSSO07', '21232f297a57a5a743894a0e4a801fc3', 'Angela.Mezzatesta@target.com.au', 6, 'byer'),
(18, 'TSSO08', '21232f297a57a5a743894a0e4a801fc3', 'Christina.Goniadis@target.com.au', 6, 'byer'),
(19, 'TSSO09', '81dc9bdb52d04dc20036dbd8313ed055', 'Alicia.Flett@target.com.au', 6, 'byer'),
(20, 'TSSO10', '21232f297a57a5a743894a0e4a801fc3', 'Noelene.Bugaj@target.com.au', 6, 'byer'),
(21, 'DIVINE01', '356282e2d4590c4ba6543df3b9cba9f9', 'almamun@divinetextile.com', 3, '1'),
(22, 'AMANG01', '81dc9bdb52d04dc20036dbd8313ed055', 'pradip@amangraphics.com', 3, '2'),
(23, 'AMANK01', '81dc9bdb52d04dc20036dbd8313ed055', 'sohail@amanknittings.com', 3, '5'),
(24, 'KDS01', '21232f297a57a5a743894a0e4a801fc3', 'mohi.uddin@kdsgroup.net', 3, '7'),
(25, 'KDS02', '81dc9bdb52d04dc20036dbd8313ed055', 'mushfiqur.rahman@kdsgroup.net', 3, '7'),
(26, 'KDS03', '21232f297a57a5a743894a0e4a801fc3', 'zakir@kdsgroup.net', 3, '7'),
(27, 'SHANTA01', '81dc9bdb52d04dc20036dbd8313ed055', 'saifullah@mascoknit.com', 3, '8'),
(28, 'SHANTA02', '81dc9bdb52d04dc20036dbd8313ed055', 'asif@mascoknit.com', 3, '8'),
(29, 'SHANTA03', '81dc9bdb52d04dc20036dbd8313ed055', 'zubair@mascoknit.com', 3, '8'),
(30, 'NORP01', '81dc9bdb52d04dc20036dbd8313ed055', 'saiful@norpknit.com', 3, '9'),
(31, 'NEWAGE01', '81dc9bdb52d04dc20036dbd8313ed055', 'kabir@gmail.com', 3, '10'),
(39, 'TAMISHNA01', '81dc9bdb52d04dc20036dbd8313ed055', 'tarik@tamishna.com', 3, '11'),
(40, 'ROVERCO01', '81dc9bdb52d04dc20036dbd8313ed055', 'rajitaa@ratthaindia.com', 3, '12'),
(35, 'TAS05', '81dc9bdb52d04dc20036dbd8313ed055', 'Arif.Ahmed@tgasourcing.com', 1, '0'),
(36, 'TAS06', '81dc9bdb52d04dc20036dbd8313ed055', 'Muntashir.Taufique@tgasourcing.com', 1, '0'),
(37, 'TAS07', '81dc9bdb52d04dc20036dbd8313ed055', 'Tareq.Ahmed@tgasourcing.com', 1, '0'),
(38, 'TAS08', '81dc9bdb52d04dc20036dbd8313ed055', 'Sanjida.Nowreen@tgasourcing.com', 1, '0'),
(41, 'Renaissance01', '81dc9bdb52d04dc20036dbd8313ed055', 'hashinur.rahman@renaissance.com.bd', 3, '13'),
(42, 'Renaissance02', '81dc9bdb52d04dc20036dbd8313ed055', 'nazmut.tarek@renaissance.com.bd', 3, '13'),
(43, 'Renaissance03', '81dc9bdb52d04dc20036dbd8313ed055', 'rajib.chowdhury@renaissance.com.bd', 3, '13'),
(44, 'Renaissance04', '81dc9bdb52d04dc20036dbd8313ed055', 'roni.roy@renaissance.com.bd', 3, '13'),
(45, 'IRIS01', '81dc9bdb52d04dc20036dbd8313ed055', 'borhan@irisgroupbd.com', 3, '14'),
(46, 'impress-newtex01', '81dc9bdb52d04dc20036dbd8313ed055', 'nurfar.islam@impress-newtex.com', 3, '15'),
(47, 'Intrarmex01', '81dc9bdb52d04dc20036dbd8313ed055', 'ferdoush@intramexgroup.com', 3, '4'),
(48, 'CIVIC01', '2f49f4708537033e725213452617f2e4', 'riyad@impressivegrp.com', 3, '3'),
(49, 'PANORAMA01', '81dc9bdb52d04dc20036dbd8313ed055', 'surender@panorama.ind.in', 3, '16');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
